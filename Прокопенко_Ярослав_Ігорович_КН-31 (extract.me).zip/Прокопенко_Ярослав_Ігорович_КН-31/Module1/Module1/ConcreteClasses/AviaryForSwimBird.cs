﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;
using Module1.Interfaces;

namespace Module1.ConcreteClasses
{
    class AviaryForSwimBird : Aviary
    {
        public readonly Lake lake;
        public readonly ISwim bird;

        public AviaryForSwimBird()
        {
            lake = new SimpleLake(5, 6);
            bird = new Penguin();
        }
        public override double GetSquare()
        {
            return lake.GetSquare();
        }
    }
}
