﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;
using Module1.Interfaces;

namespace Module1.ConcreteClasses
{
    class Zoo : ISquare
    {
        public List<AviaryForFlyAndSwimBird> aviaryForFlyAndSwimBirds = new List<AviaryForFlyAndSwimBird>();
        public List<AviaryForSwimBird> aviaryForSwimBirds = new List<AviaryForSwimBird>();
        public List<AviaryForRunAndSwimBird> aviaryForRunAndSwimBirds = new List<AviaryForRunAndSwimBird>();

        public Zoo()
        {
            
        }

        public Zoo(List<AviaryForFlyAndSwimBird> aviaryForFlyAndSwimBirds, List<AviaryForSwimBird> aviaryForSwimBirds,
            List<AviaryForRunAndSwimBird> aviaryForRunAndSwimBirds)
        {
            this.aviaryForFlyAndSwimBirds = aviaryForFlyAndSwimBirds;
            this.aviaryForRunAndSwimBirds = aviaryForRunAndSwimBirds;
            this.aviaryForSwimBirds = aviaryForSwimBirds;
        }
        public double GetSquare()
        {
            double sum1 = 0;
            double sum2 = 0;
            double sum3 = 0;
            foreach (var item in aviaryForFlyAndSwimBirds)
            {
                sum1 += item.GetSquare();
            }
            Console.WriteLine("Summary square of aviary for fly and swim birds is: " + sum1);

            foreach (var item in aviaryForRunAndSwimBirds)
            {
                sum2 += item.GetSquare();
            }

            Console.WriteLine("Summary square of aviary for run and swim birds is: " + sum2);

            foreach (var item in aviaryForSwimBirds)
            {
                sum3 += item.GetSquare();
            }

            Console.WriteLine("Summary square of aviary for swim birds is: " + sum3);

            return sum1 + sum2 + sum3;
        }
    }
}
