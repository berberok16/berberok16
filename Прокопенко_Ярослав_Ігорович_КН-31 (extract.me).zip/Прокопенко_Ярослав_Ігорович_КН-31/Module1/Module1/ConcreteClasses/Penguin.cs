﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;
using Module1.Interfaces;


namespace Module1.ConcreteClasses
{
    class Penguin : Bird, ISwim
    {
        public Penguin(string name=""):base(name)
        {
        }
        public override void Breathe()
        {
            Console.WriteLine("Penguin breathe");
        }

        public void Swim()
        {
            Console.WriteLine("Penguin Swim");
        }
    }
}
