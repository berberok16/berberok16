﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.Interfaces;
using Module1.AbstractClasses;


namespace Module1.ConcreteClasses
{
    class AviaryForFlyAndSwimBird : Aviary
    {
        public readonly Fence fence;
        public readonly Land land;
        public readonly Lake lake;
        public readonly IFlyAndSwim bird;
        public AviaryForFlyAndSwimBird()
        {
            fence = new SimpleFence("Set");
            land = new SimpleLand(5, 7);
            lake = new SimpleLake(2, 4);
            bird = new Duck(); // якщо б ми мали більше тварин, що реалізують цей інтерфейс, то задавали б це значення при створенні об'єкту
        }
        
        public override double GetSquare()
        {
            return (land.GetSquare() + lake.GetSquare()); 
        }
    }
}
