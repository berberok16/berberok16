﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;
using Module1.Interfaces;


namespace Module1.ConcreteClasses
{
    class Duck : Bird, IFlyAndSwim
    {
        public Duck(string name = ""):base(name)
        {
        }
        public override void Breathe()
        {
            Console.WriteLine("Duck breathe");
        }

        public void Fly()
        {
            Console.WriteLine("Fly");
        }

        public void Swim()
        {
            Console.WriteLine("Swim");
        }
    }
}
