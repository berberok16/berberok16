﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;
using Module1.Interfaces;

namespace Module1.ConcreteClasses
{
    class AviaryForRunAndSwimBird : Aviary
    {
        public readonly Fence fence;
        public readonly Land land;
        public readonly Lake lake;
        public readonly IRunAndSwim bird;

        public AviaryForRunAndSwimBird()
        {
            fence = new SimpleFence("High fence");
            land = new SimpleLand(5.9, 9.9);
            lake = new SimpleLake(3, 4.5);
            bird = new Kiwi();
        }
        public override double GetSquare()
        {
            return (land.GetSquare() + lake.GetSquare());
        }
    }
}
