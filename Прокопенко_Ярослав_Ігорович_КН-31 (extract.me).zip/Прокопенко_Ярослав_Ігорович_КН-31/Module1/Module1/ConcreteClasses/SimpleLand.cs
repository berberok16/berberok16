﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;

namespace Module1.ConcreteClasses
{
    class SimpleLand : Land
    {
        public SimpleLand():base()
        {
        }

        public SimpleLand(double len, double width): base(len, width)
        {
        }
        public override double GetSquare()
        {
            return this.Length * this.Width;
        }
    }
}
