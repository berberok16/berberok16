﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;
using Module1.Interfaces;


namespace Module1.ConcreteClasses
{
    class Kiwi : Bird, IRunAndSwim
    {
        public Kiwi(string name=""):base(name)
        {
        }
        public override void Breathe()
        {
            Console.WriteLine("Kiwi breathe");
        }

        public void Run()
        {
            Console.WriteLine("Kiwi Run");
        }

        public void Swim()
        {
            Console.WriteLine("Kiwi Swim");
        }
    }
}
