﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.AbstractClasses;

namespace Module1.ConcreteClasses
{
    class SimpleFence : Fence
    {
        private string type;

        public override string fenceType { get => type; set => type = value; }

        public SimpleFence(string type)
        {
            this.type = type;
        }

        public SimpleFence() : this("Simple fence")
        {
        }
    }
}
