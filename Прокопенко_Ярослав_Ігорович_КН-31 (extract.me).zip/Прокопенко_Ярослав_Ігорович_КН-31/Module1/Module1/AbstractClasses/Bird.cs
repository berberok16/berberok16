﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module1.AbstractClasses
{
    public abstract class Bird
    {
        public string Name { get; set; }
        public Bird(string name = "bird")
        {
            Name = name;
        }

        public abstract void Breathe();
    }
}
