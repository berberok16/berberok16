﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.Interfaces;

namespace Module1.AbstractClasses
{
    public abstract class Land : ISquare
    {
        public double Length { get; set; }
        public double Width { get; set; }

        public Land(double len, double width)
        {
            Length = len;
            Width = width;
        }

        public Land(): this(1, 1)
        {
        }
        public abstract double GetSquare();
    }
}
