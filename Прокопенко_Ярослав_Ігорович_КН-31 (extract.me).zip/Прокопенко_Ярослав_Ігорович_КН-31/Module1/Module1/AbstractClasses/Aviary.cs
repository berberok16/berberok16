﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.Interfaces;

namespace Module1.AbstractClasses
{
    public abstract class Aviary : ISquare
    {
        public abstract double GetSquare();
    }
}
