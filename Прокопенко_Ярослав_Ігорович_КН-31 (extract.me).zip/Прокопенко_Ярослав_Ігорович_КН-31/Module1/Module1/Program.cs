﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module1.ConcreteClasses;
using Module1.AbstractClasses;
using Module1.Interfaces;

namespace Module1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<AviaryForFlyAndSwimBird> flyAndSwimBirds = new List<AviaryForFlyAndSwimBird>
            {
                new AviaryForFlyAndSwimBird(),
                new AviaryForFlyAndSwimBird(),
                new AviaryForFlyAndSwimBird()
            };

            List<AviaryForRunAndSwimBird> runAndSwimBird  = new List<AviaryForRunAndSwimBird>
            {
                new AviaryForRunAndSwimBird(),
                new AviaryForRunAndSwimBird(),
                new AviaryForRunAndSwimBird()
            };

            List<AviaryForSwimBird> aviaryForSwimBirds = new List<AviaryForSwimBird>
            {
                new AviaryForSwimBird(),
                new AviaryForSwimBird(),
                new AviaryForSwimBird()
            };

            Zoo zoo = new Zoo(flyAndSwimBirds, aviaryForSwimBirds, runAndSwimBird);
            double sum = zoo.GetSquare();
            Console.WriteLine("Summary square of all aviaries is: " + sum);
            Console.ReadKey();
        }
    }
}
